<?php

namespace App\Filament\Resources\InputProfileResource\Pages;

use App\Filament\Resources\InputProfileResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewInputProfile extends ViewRecord
{
    protected static string $resource = InputProfileResource::class;
}
