<?php

namespace App\Filament\Resources\SasaranKinerjaResource\Pages;

use App\Filament\Resources\SasaranKinerjaResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSasaranKinerja extends CreateRecord
{
    protected static string $resource = SasaranKinerjaResource::class;
}
