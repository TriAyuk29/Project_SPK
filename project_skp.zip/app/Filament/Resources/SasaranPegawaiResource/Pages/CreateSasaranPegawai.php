<?php

namespace App\Filament\Resources\SasaranPegawaiResource\Pages;

use App\Filament\Resources\SasaranPegawaiResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSasaranPegawai extends CreateRecord
{
    protected static string $resource = SasaranPegawaiResource::class;
}
