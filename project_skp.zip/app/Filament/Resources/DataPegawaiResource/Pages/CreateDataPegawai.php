<?php

namespace App\Filament\Resources\DataPegawaiResource\Pages;

use App\Filament\Resources\DataPegawaiResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataPegawai extends CreateRecord
{
    protected static string $resource = DataPegawaiResource::class;
}
